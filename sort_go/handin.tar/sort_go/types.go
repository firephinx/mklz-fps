package main

// Here you can define the type of the element to be sorted.
type Element Pair
type ElementSlice []Pair
